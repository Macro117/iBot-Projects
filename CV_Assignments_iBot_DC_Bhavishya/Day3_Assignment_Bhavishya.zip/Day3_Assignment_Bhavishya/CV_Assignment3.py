import os
import zipfile
import shutil
import random
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# ==========================================
# 1. DATA PREPARATION (Extract & Split)
# ==========================================

def prepare_data_from_zip(zip_path, base_dir='data'):
    temp_extract_dir = 'temp_raw_images'

    # Check if the file exists
    if not os.path.exists(zip_path):
        print(f"Error: File {zip_path} not found.")
        return

    # Check if it's a valid zip file
    if not zipfile.is_zipfile(zip_path):
        size = os.path.getsize(zip_path)
        print(f"Error: {zip_path} is not a valid zip file. Size: {size} bytes.")
        print("Try redownloading the file or checking if it is an HTML error page.")
        return

    if os.path.exists(temp_extract_dir):
        shutil.rmtree(temp_extract_dir)

    print(f"Extracting {zip_path}...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(temp_extract_dir)

    # Create standard 80/10/10 directory structure
    splits = ['train', 'val', 'test']
    classes = ['cats', 'dogs']
    for split in splits:
        for cls in classes:
            os.makedirs(os.path.join(base_dir, split, cls), exist_ok=True)

    # Recursively find all image files regardless of nested folders
    all_image_paths = []
    for root, dirs, files in os.walk(temp_extract_dir):
        for f in files:
            if f.lower().endswith(('.jpg', '.jpeg', '.png')):
                all_image_paths.append(os.path.join(root, f))

    # Filter by prefix
    cat_files = [f for f in all_image_paths if os.path.basename(f).lower().startswith('cat')]
    dog_files = [f for f in all_image_paths if os.path.basename(f).lower().startswith('dog')]

    def split_and_copy(files, class_name):
        if not files:
            return
        random.shuffle(files)
        total = len(files)
        train_idx = int(total * 0.8)
        val_idx = train_idx + int(total * 0.1)

        groups = {
            'train': files[:train_idx],
            'val': files[train_idx:val_idx],
            'test': files[val_idx:]
        }

        for split, file_list in groups.items():
            for f_path in file_list:
                dst = os.path.join(base_dir, split, class_name, os.path.basename(f_path))
                shutil.copy2(f_path, dst)

    print(f"Organizing {len(cat_files)} cats and {len(dog_files)} dogs...")
    split_and_copy(cat_files, 'cats')
    split_and_copy(dog_files, 'dogs')

    shutil.rmtree(temp_extract_dir)
    print("Data organization complete.")

# ==========================================
# 2. MODEL, TRAINING & EVALUATION
# ==========================================

def main():
    # --- CONFIGURATION ---
    ZIP_FILE_NAME = '/content/train.zip'
    DATA_DIR = 'data'
    DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Prepare data if not already done
    if not os.path.exists(DATA_DIR):
        prepare_data_from_zip(ZIP_FILE_NAME, DATA_DIR)

    if not os.path.exists(os.path.join(DATA_DIR, 'train')):
        print("Training data not found. Please check the zip file.")
        return

    # 5+ Augmentation Techniques
    train_transforms = transforms.Compose([
        transforms.Resize(256),
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(20),
        transforms.ColorJitter(brightness=0.2, contrast=0.2),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    val_test_transforms = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # Data Loaders
    train_ds = datasets.ImageFolder(os.path.join(DATA_DIR, 'train'), train_transforms)
    val_ds = datasets.ImageFolder(os.path.join(DATA_DIR, 'val'), val_test_transforms)
    test_ds = datasets.ImageFolder(os.path.join(DATA_DIR, 'test'), val_test_transforms)

    train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=32, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=32, shuffle=False)

    # Transfer Learning
    model = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
    for param in model.parameters():
        param.requires_grad = False

    model.fc = nn.Linear(model.fc.in_features, 2)
    model.to(DEVICE)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.fc.parameters(), lr=0.001)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', patience=2, factor=0.1)

    # Training
    history = {'train_loss': [], 'val_loss': [], 'train_acc': [], 'val_acc': []}
    num_epochs = 10
    best_acc = 0.0

    print("Starting Training...")
    for epoch in range(num_epochs):
        model.train()
        r_loss, r_corr = 0.0, 0
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            _, preds = torch.max(outputs, 1)
            r_loss += loss.item() * inputs.size(0)
            r_corr += torch.sum(preds == labels.data)

        model.eval()
        v_loss, v_corr = 0.0, 0
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                _, preds = torch.max(outputs, 1)
                v_loss += loss.item() * inputs.size(0)
                v_corr += torch.sum(preds == labels.data)

        train_acc = r_corr.double() / len(train_ds)
        val_acc = v_corr.double() / len(val_ds)

        history['train_acc'].append(train_acc.cpu())
        history['val_acc'].append(val_acc.cpu())
        history['train_loss'].append(r_loss / len(train_ds))
        history['val_loss'].append(v_loss / len(val_ds))

        scheduler.step(v_loss / len(val_ds))
        print(f"Epoch {epoch+1}/{num_epochs} - Train Acc: {train_acc:.4f}, Val Acc: {val_acc:.4f}")

        if val_acc > best_acc:
            best_acc = val_acc
            torch.save(model.state_dict(), 'best_model.pth')

    # Final Evaluation
    print("\nEvaluating on Test Set...")
    model.load_state_dict(torch.load('best_model.pth'))
    model.eval()
    y_true, y_pred = [], []
    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            y_true.extend(labels.cpu().numpy())
            y_pred.extend(preds.cpu().numpy())

    print(f"Test Accuracy: {100 * np.mean(np.array(y_true) == np.array(y_pred)):.2f}%")

    # Visuals
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.plot(history['train_loss'], label='Train')
    plt.plot(history['val_loss'], label='Val')
    plt.title('Loss')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(history['train_acc'], label='Train')
    plt.plot(history['val_acc'], label='Val')
    plt.title('Accuracy')
    plt.legend()
    plt.show()

    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Cat', 'Dog'], yticklabels=['Cat', 'Dog'])
    plt.title('Confusion Matrix')
    plt.show()

if __name__ == '__main__':
    main()